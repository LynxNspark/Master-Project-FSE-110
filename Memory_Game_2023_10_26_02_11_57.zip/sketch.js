function setup() {
  createCanvas(800, 800);
}
var rows = 5;
var columns = 4;

function draw() {
  for(i=0;i<rows;i++){
    for(j=0;j<columns;j++){
  rect(80*i+50,80*j+50,75,75);
  fill('orange');}}
}
function  mousePressed() {
  let mouseCoord = createVector(mouseX, mouseY);
  return mouseCoord;
  print(v.array());
}
